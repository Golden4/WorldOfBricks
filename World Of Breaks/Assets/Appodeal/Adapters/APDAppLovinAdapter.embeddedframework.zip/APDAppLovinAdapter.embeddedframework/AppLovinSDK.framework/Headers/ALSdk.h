//
//  AppLovinSdk.h
//
//  Created by Basil Shikin on 2/1/12.
//  Copyright © 2018 AppLovin Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import "ALSdkSettings.h"
#import "ALAdService.h"
#import "ALNativeAdService.h"
#import "ALPostbackService.h"
#import "ALEventService.h"
#import "ALVariableService.h"
#import "ALUserService.h"
#import "ALSdkConfiguration.h"
#import "ALErrorCodes.h"
#import "ALMediationProvider.h"

NS_ASSUME_NONNULL_BEGIN

/**
 * This is a base class for the AppLovin iOS SDK.
 */
@interface ALSdk : NSObject

/**
 * @name SDK Configuration
 */

/**
 * This SDK's key.
 */
@property (strong, nonatomic, readonly) NSString *sdkKey;

/**
 * This SDK's settings.
 */
@property (strong, nonatomic, readonly) ALSdkSettings *settings;

/**
 * Set plugin version.
 *
 * This is mainly used internally, however if you've written a mediation adaptor or plugin,
 * you can set this. Common examples include things like "Cocos2D Plugin v1.0".
 *
 * @param pluginVersion Some descriptive string which identifies the plugin.
 */
- (void)setPluginVersion:(NSString *)pluginVersion;

/**
 * Set mediation provider using one of the provided strings in ALMediationProvider.h, or your own if not defined.
 */
@property (atomic, copy, nullable) NSString *mediationProvider;

/**
 * @name SDK Information
 */

/**
 * Get the current version of the SDK.
 *
 * @return The current SDK version.
 */
+ (NSString *)version;

/**
 * Get the current version of the SDK in numeric format.
 *
 * @return The current SDK version in numeric format.
 */
+ (NSUInteger)versionCode;

/**
 * @name SDK Services
 */

/**
 * Get an instance of AppLovin Ad service. This service is
 * used to fetch and display ads from AppLovin servers.
 *
 * @return Ad service. Guaranteed not to be null.
 */
@property (strong, nonatomic, readonly) ALAdService *adService;

/**
 * Get an instance of AppLovin Native Ad service. This service is
 * used to fetch and display native ads from AppLovin servers.
 *
 * @return Native ad service. Guaranteed not to be null.
 */
@property (strong, nonatomic, readonly) ALNativeAdService *nativeAdService;

/**
 * Get an instance of the AppLovin postback service. This service is used to dispatch HTTP GET postbacks to arbitrary URLs.
 *
 * @return Postback service. Guaranteed not to be null.
 */
@property (strong, nonatomic, readonly) ALPostbackService *postbackService;

/**
 * Get an instance of the AppLovin event service. This service is used to track post-install user events.
 *
 * @return Event service. Guaranteed not to be null.
 */
@property (strong, nonatomic, readonly) ALEventService *eventService;

/**
 * Service object for performing user-related tasks.
 *
 * @return User service. Guaranteed not to be null.
 */
@property (strong, nonatomic, readonly) ALUserService *userService;

/**
 * Get an instance of the AppLovin variable service. This service is used to perform various AB tests that you have set up on your AppLovin dashboard on your users.
 *
 * @return Variable service. Guaranteed not to be null.
 */
@property (strong, nonatomic, readonly) ALVariableService *variableService;

/**
 * Set a string which identifies the current user, which will be passed through to your server via our optional S2S postbacks.
 *
 * If you're using reward validation, you can optionally set a user identifier to be included with
 * currency validation postbacks. For example, a user name. We'll include this in the postback when we
 * ping your currency endpoint from our server.
 */
@property (copy, nonatomic, nullable) NSString *userIdentifier;

/**
 * @name SDK Initialization
 */

typedef void (^ALSdkInitializationCompletionHandler)(ALSdkConfiguration *configuration);

/**
 * Initialize the SDK.
 */
- (void)initializeSdk;

/**
 * Initialize the SDK with a given completion block.
 *
 * The callback will be invoked on the main thread.
 *
 * @param completionHandler The callback that will be run when the SDK finishes initializing.
 */
- (void)initializeSdkWithCompletionHandler:(nullable ALSdkInitializationCompletionHandler)completionHandler;

/**
 * Initialize the default instance of AppLovin SDK.
 *
 * Please make sure that application's
 * <code>Info.plist</code> includes a property 'AppLovinSdkKey' that is set to provided SDK key.
 */
+ (void)initializeSdk;

/**
 * Initialize the default instance of AppLovin SDK.
 *
 * Please make sure that application's
 * <code>Info.plist</code> includes a property 'AppLovinSdkKey' that is set to provided SDK key.
 *
 * @param completionHandler The callback that will be run when the SDK finishes initializing.
 */
+ (void)initializeSdkWithCompletionHandler:(nullable ALSdkInitializationCompletionHandler)completionHandler;

/**
 * @name Getting SDK Instances
 */

/**
 * Get a shared instance of AppLovin SDK.
 *
 * Please make sure that application's
 * <code>Info.plist</code> includes a property 'AppLovinSdkKey' that is set to provided SDK key.
 *
 * @return An instance of AppLovinSDK
 */
+ (nullable ALSdk *)shared;

/**
 * Get an instance of AppLovin SDK using default SDK settings.
 *
 * @param sdkKey         SDK key to use. Must not be nil.
 *
 * @return An instance of AppLovinSDK
 */
+ (nullable ALSdk *)sharedWithKey:(NSString *)sdkKey;

/**
 * Get an instance of AppLovin SDK.
 * 
 * @param sdkKey         SDK key to use. Must not be nil.
 * @param settings       User-provided settings. Must not be nil, but can be an empty <code>[[ALSdkSettings alloc] init]</code> object.
 * 
 * @return An instance of AppLovinSDK
 */
+ (nullable ALSdk *)sharedWithKey:(NSString *)sdkKey settings:(ALSdkSettings *)settings;

- (id)init __attribute__((unavailable("Use [ALSdk shared] instead of alloc-init pattern.")));

@end

NS_ASSUME_NONNULL_END
