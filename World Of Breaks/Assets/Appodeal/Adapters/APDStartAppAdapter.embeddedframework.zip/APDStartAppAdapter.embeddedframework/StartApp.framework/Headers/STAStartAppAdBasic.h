//
//  STAStartAppAdBasic.h
//  StartApp
//
//  Created by StartApp on 3/3/15.
//  Copyright (c) 2013 StartApp. All rights reserved.
//  SDK version 4.0.0

#import <Foundation/Foundation.h>

@interface STAStartAppAdBasic : NSObject

+(BOOL)showAd;
@end
